﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace patient
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are closing the out-patient form");
            this.Close();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Text = "";
            total.Text = "";
        }

        private void btn_cal_Click(object sender, EventArgs e)
        {
            double result;
            double n1;
            double n2;

            n1 = double.Parse(txt1.Text);
            n2 = double.Parse(txt2.Text);

            result = n1 + n2;
            total.Text = result.ToString();
        }
        string path = Environment.CurrentDirectory + "/" + "out-patient.txt";
        private void btn_save_Click(object sender, EventArgs e)
        {
           
            using (StreamWriter txt = new StreamWriter(path))
            {
                txt.WriteLine(txt1.Text);
                txt.WriteLine(txt2.Text);
                txt.WriteLine(total.Text);
                MessageBox.Show("Record Saved Successfully");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!File.Exists(path))
            {
                File.CreateText(path);
                MessageBox.Show("File Created");
            }
           
        }
    }
}
