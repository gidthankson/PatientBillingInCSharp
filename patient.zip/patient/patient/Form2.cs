﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace patient
{
    public partial class Form2 : Form
    {
 

        public Form2()
        {
            InitializeComponent();

        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are about to close the In-Patient form");
            this.Close();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            MessageBox.Show("you are about to clear text boxes");
               
            txt1.Text ="";
            txt2.Text = "";
            txt3.Text = "";
            txt4.Text = "";
            total.Text = "";
            

        }

        private void btn_cal_Click(object sender, EventArgs e)
        {
            double result;
            double n1;
            double n2;
            double n3;
            double n4;
            n1 = double.Parse(txt1.Text);
            n2 = double.Parse(txt2.Text);
            n3 = double.Parse(txt3.Text);
            n4 = double.Parse(txt4.Text);

            result = (n1 * n2) + n3 + n4;
            total.Text = result.ToString();

        }
    }
}
